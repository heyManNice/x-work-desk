#!/usr/bin/env bash
# xworkd 服务端一键安装（需 root）。目标需为可运行 GNOME 桌面的 Ubuntu/Debian 主机。
set -euo pipefail
if [[ $(id -u) -ne 0 ]]; then echo "需要 root"; exit 1; fi
PREFIX="/opt/xworkd"
mkdir -p "$PREFIX"
echo "[xworkd] 安装运行/会话基础依赖（ffmpeg/Xorg dummy 等）..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null 2>&1 || true
apt-get install -y ffmpeg xserver-xorg-video-dummy x11-xserver-utils xauth xclip dbus-x11 >/dev/null 2>&1 || true
install -m 0755 xworkd "$PREFIX/xworkd"
rm -rf "$PREFIX/www"
cp -r www "$PREFIX/www"
cat > /etc/systemd/system/xworkd.service <<UNIT
[Unit]
Description=XWorkDesk remote desktop server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
ExecStart=$PREFIX/xworkd --auth shadow --www-root $PREFIX/www --port 5268
WorkingDirectory=$PREFIX
Restart=on-failure
RestartSec=3
LimitNOFILE=65536
StandardOutput=journal
StandardError=journal
SyslogIdentifier=xworkd
NoNewPrivileges=no
PrivateTmp=no

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable xworkd >/dev/null 2>&1 || true
systemctl restart xworkd
sleep 1
echo XWORKD_INSTALL_OK
