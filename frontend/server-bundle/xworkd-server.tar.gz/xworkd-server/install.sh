#!/usr/bin/env bash
# xworkd 服务端一键安装（需 root）。目标需为可运行 GNOME 桌面的 Ubuntu/Debian 主机。
set -euo pipefail
if [[ $(id -u) -ne 0 ]]; then echo "需要 root"; exit 1; fi
PREFIX="/opt/xworkd"
mkdir -p "$PREFIX"
echo "[xworkd] 安装运行/会话基础依赖（Xorg dummy、X 运行库、libopus 等）..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null 2>&1 || true
apt-get install -y xserver-xorg-video-dummy x11-xserver-utils xauth xclip dbus-x11 libopus0 libx11-6 libxext6 libxtst6 libxfixes3 libxrandr2 >/dev/null 2>&1 || true
install -m 0755 xworkd "$PREFIX/xworkd"
# 输入法中继引擎（随包分发则装上；组件 XML 必须进 /usr/share/ibus/component）
if [[ -f xworkd-im && -f xworkd-im.xml ]]; then
    echo "[xworkd] 安装输入法中继引擎（xworkd-im）..."
    mkdir -p /usr/libexec/xworkd
    install -m 0755 xworkd-im /usr/libexec/xworkd/xworkd-im
    install -m 0644 xworkd-im.xml /usr/share/ibus/component/xworkd-im.xml
    for pkg in libibus-1.0-5 ibus; do
        dpkg -s "$pkg" >/dev/null 2>&1 || apt-get install -y "$pkg" >/dev/null 2>&1 || true
    done
    ibus write-cache >/dev/null 2>&1 || true
fi
cat > /etc/systemd/system/xworkd.service <<UNIT
[Unit]
Description=XWorkDesk remote desktop server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
ExecStart=$PREFIX/xworkd --auth shadow --port 5268
WorkingDirectory=$PREFIX
Restart=on-failure
RestartSec=3
LimitNOFILE=65536
StandardOutput=journal
StandardError=journal
SyslogIdentifier=xworkd
NoNewPrivileges=no
PrivateTmp=no

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable xworkd >/dev/null 2>&1 || true
# 接入实体机登录拦截 PAM（幂等；无 GDM 自动跳过）。cwd = 解包目录
bash install-pam.sh
systemctl restart xworkd
sleep 1
echo XWORKD_INSTALL_OK
